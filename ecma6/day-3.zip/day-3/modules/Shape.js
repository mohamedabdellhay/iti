export default class Shape {
  calcArea() {
    return 0;
  }
}
